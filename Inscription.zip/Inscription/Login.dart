import 'dart:io';

void main() {
  print(
      "********************** Bienvenu dans notre application **********************");

  List liste = [];
  int x = 0;
  while (x < 1) {
    int choix = menu();
    switch (choix) {
      case 1:
        {
          print("Entrer l'email :");
          String email = stdin.readLineSync()!;
          print("Entrer le mot de passe :");
          String pass = stdin.readLineSync()!;
          inscription(email, pass);
          if (verifierEmail(email) == true || verifierPass(pass) == true) {
            ajouterUser(liste, email, pass);
            print("Ajouter avec succes ");
          } else {
            print("L'email ou mot de passe est vide ou incorret !!!");
          }
        }
        break;
      case 2:
        {
          print("La liste des utilisateurs est :");
          afficherUsers(liste);
        }
        break;
      case 3:
        {
          print("Entrer l'email a modiffier :");
          String email = stdin.readLineSync()!;
          int index = chercherEmail(liste, email);
          if (index > -1) {
            modiffierPass(liste, index);
            print("Modiffier avec succee ");
          } else {
            print("L'email n'existe pas !!!");
          }
        }
        break;
      case 4:
        {
          print("Entrer l'email a suprimmer :");
          String email = stdin.readLineSync()!;
          int index = chercherEmail(liste, email);
          if (index > -1) {
            suprimmerCompt(liste, index);
            print("Suprimmer avec succee ");
          } else {
            print("L'email n'existe pas !!!");
          }
        }
        break;
      case 5:
        {
          print("Fin de Programme !!!");
          exit(0);
        }
    }
  }
}

void inscription(String email, String pass) {
  verifierEmail(email);
  verifierPass(pass);
}

bool verifierEmail(String email) {
  String text = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
  RegExp reg = new RegExp(text);
  if (email == "") {
    return false;
  } else if (reg.hasMatch(email)) {
    return true;
  } else {
    return false;
  }
}

bool verifierPass(String pass) {
  String text = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{6,}$';
  RegExp reg = new RegExp(text);
  if (reg.hasMatch(pass)) {
    return true;
  } else {
    return false;
  }
}

void ajouterUser(List l, String email, String pass) {
  l.add(email);
  l.add(pass);
}

void afficherUsers(List l) {
  for (int i = 0; i < l.length; i++) {
    print(l[i]);
  }
}

int chercherEmail(List l, String email) {
  int index = -1;
  for (int i = 0; i < l.length; i++) {
    if (email == l[i]) {
      index = i;
    }
  }
  return index;
}

void modiffierPass(List l, int index) {
  print("Donner le neauveau mot de passe :");
  String pass = stdin.readLineSync()!;
  l[index + 1] = pass;
}

void suprimmerCompt(List l, int index) {
  print("Donner le mot de passe :");
  String pass = stdin.readLineSync()!;
  if (l[index + 1] == pass) {
    l.removeAt(index);
    l.removeAt(index + 1);
  }
}

int menu() {
  print(
      "\n---------------------------------------------------------------------------------\n");
  print("MENU :\n");
  print(
      "1- Insription\n2- Afficher les utilisatues\n3- Modiffier mot de passe\n4- Suprimmer compt\n5- Exit");
  print("Donner Voter Choix :");
  int choix = int.parse(stdin.readLineSync()!);
  return choix;
}
